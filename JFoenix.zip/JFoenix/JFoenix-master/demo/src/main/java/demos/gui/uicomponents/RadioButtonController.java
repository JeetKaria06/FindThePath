package demos.gui.uicomponents;

import io.datafx.controller.ViewController;

@ViewController(value = "/fxml/ui/RadioButton.fxml", title = "Material Design Example")
public class RadioButtonController {

}
